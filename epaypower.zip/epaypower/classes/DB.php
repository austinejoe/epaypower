<?php
class DB {
    private $host = "localhost";
    private $user = "root";
    private $password = "austinejoe";
    private $database = "epaypower";
    private $database_w = "world";
    public $conn;
    public $conn_w;

    function __construct() {
        $this->conn = $this->getConnection_a();
        $this->conn_w = $this->getConnection_w();
    }

    public function getConnection_a(){
        $conn = mysqli_connect($this->host,$this->user,$this->password,$this->database);
        return $conn;
    }
    public function getConnection_w(){
        $conn_w = mysqli_connect($this->host,$this->user,$this->password,$this->database_w);
        return $conn_w;
    }
} 