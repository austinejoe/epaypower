<?php
class MailDef {
    public $mail;

    public function mailDefinition($subject,$body,$email){
        include_once ('class.phpmailer.php');
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->Host = 'twentyeight.qservers.net';
        $mail->Port = '465';
        $mail->SMTPSecure = 'ssl';
        $mail->SMTPAuth = true;
        $mail->Username = 'twandikire@imbereheza.com';
        $mail->Password = 'imbereheza.com/080';
        $mail->From = 'twandikire@imbereheza.com';
        $mail->FromName = 'Imbereheza';
        $mail->AddCC('dfelix001@gmail.com');
        $mail->AddAddress($email);
        $mail->AddEmbeddedImage('../images/imbereheza-logo.png','logoimg');
        $mail->AddEmbeddedImage('../images/facebook.png','facebook');
        $mail->AddEmbeddedImage('../images/twitter.png','twitter');
        $mail->AddEmbeddedImage('../images/instagram.png','instagram');
        $mail->AddEmbeddedImage('../images/youtube.png','youtube');
        $mail->WordWrap = 5000;
        $mail->SMTPDebug = 0;
        $mail->IsHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $body;
        return $mail;
    }
} 