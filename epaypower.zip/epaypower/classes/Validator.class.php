<?php
class Validator {
    public static function blank($input){
        if(strlen(trim($input)) == 0){
            return true;
        }else{
            return false;
        }
    }

    public static function matchName($input){
        if(!preg_match("/[-'a-zA-Z]+$/",$input)){
            return true;
        }else{
            return false;
        }
    }

    public static function isDigit($input){
        if(!preg_match("/[\d]+$/",$input)){
            return true;
        }else{
            return false;
        }
    }

    public static function isTel($input){
        if(!preg_match("/[0-9]{9,10}$/",$input)){
            return true;
        }else{
            return false;
        }
    }

    public static function isEmail($input){
        if(!filter_var($input,FILTER_VALIDATE_EMAIL)){
            return true;
        }else{
            return false;
        }
    }

    public static function isStrongPassword($input){
        $uppercase = preg_match('/[A-Z]+/',$input);
        $lowercase = preg_match('/[a-z]+/', $input);
        $number    = preg_match('/[0-9]+/', $input);
        $specialChars = preg_match('/[^\w]+/', $input);

        if(!$uppercase || !$lowercase || !$number || !$specialChars || strlen($input) < 8) {
            return true;
        }else{
            return false;
        }
    }

    public static function test_input($data) {
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
    }

    public static  function isBadWord($data){
//First we list the bad words in array
        $abusive = array(
            'fuck',
            'sex',
            'kill',
            'dick',
            'pussy',
            'prick',
            'fool',
            'idiot',
            'jerk',
            'lame',
            'stupid',
            'ass',
            'cock',
            'cunt',
            'asshole',
            'fuck off',
            'bitch',
            'prick',
            'bastard',
            'dickhead',
            'whore',
            'ashawo'
        );

//Then we perform the bad word check
        foreach($abusive as $filter){
            if(stristr($data,$filter)){
                return true;
            }
        }
        return false;
    }

    public static function isISBN($data){
        if(!preg_match('/^(?=(?:\D*\d){10}(?:(?:\D*\d){3})?$)[\d-]+$/',$data)){
            return true;
        }else{
            return false;
        }
    }

    public static function isCountryCode($data){
        if(!preg_match('/^\+[0-9]+/',$data)){
            return true;
        }else{
            return false;
        }
    }

    public static function isURL($data){
        if(!filter_var($data,FILTER_VALIDATE_URL)){
            return true;
        }else{
            return false;
        }
    }
} 