<?php
switch($_POST['identity']){
    case 'electricity';
        $output = '
        <form class="buy_power_form">
        <div class="form-group row">
            <div class="col-lg-6">
                <select name="state" data-addui="input">
                    <option value="">choose option</option>
                </select>
            </div>
            <div class="col-lg-6">
                 <select name="state" data-addui="input">
                    <option value="">choose option</option>
                    <option value="Prepaid">Prepaid</option>
                    <option value="Postpaid">Postpaid</option>
                </select>
            </div>
        </div>
         <div class="form-group row">
            <div class="col-lg-6">
                <input type="number" name="meter_number" data-addui="input" placeholder="meter number">
            </div>
            <div class="col-lg-6">
                 <input type="number" name="amount" data-addui="input" placeholder="amount">
            </div>
        </div>
         <div class="form-group row">
            <div class="col-lg-6">
                <input type="email" name="amount" data-addui="input" placeholder="your email">
            </div>
            <div class="col-lg-6">
                  <input type="tel" name="phone" data-addui="input" placeholder="your phone number">
            </div>
        </div>
        <div class="form-group">
        <input type="hidden" name="identity" value="electricity"/>
        <input type="submit" class="btn btn-block text-light" style="background-color: red" value="Submit"/>
        </div>
        </form>
        ';
        echo $output;
}