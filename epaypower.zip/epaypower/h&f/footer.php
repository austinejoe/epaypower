<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="http://localhost/epaypower/js/jquery.min.js"></script>
<script src="http://localhost/epaypower/js/bootstrap.bundle.min.js"></script>
<script type="application/javascript" src="http://localhost/epaypower/js/all.min.js"></script>
<script type="application/javascript" src="http://localhost/epaypower/js/jquery-ui.min.js"></script>
<script type="application/javascript" src="http://localhost/epaypower/js/script.js"></script>
<script type="application/javascript" src="http://localhost/epaypower/js/addInput.js"></script>
<script type="application/javascript" src="http://localhost/epaypower/js/addSelect.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
</body>
</html>