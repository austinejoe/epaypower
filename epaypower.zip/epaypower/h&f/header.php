<!doctype html>
<html lang="en" xmlns="http://www.w3.org/1999/html">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="description" content="buy electricity, recharge card, buy power,tv subscription, buy data">
    <meta name="keywords" content="buy electricity, recharge card, buy power,tv subscription, buy data">
    <meta name="author" content="Bebeque Limited">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="msapplication-TileColor" content="#2b5797">
    <meta name="theme-color" content="#ffffff">
    <title>epaypower - buy electricity</title>


    <link rel="icon" href="http://localhost/epaypower/images/epaylogo.jpg">
    <link rel="stylesheet" href="http://localhost/epaypower/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://localhost/epaypower/css/all.css"/>
    <link rel="stylesheet" href="http://localhost/epaypower/css/jquery-ui.min.css"/>
    <link rel="stylesheet" href="http://localhost/epaypower/css/style.css"/>
    <link rel="stylesheet" href="http://localhost/epaypower/css/animate.css"/>
    <link rel="stylesheet" href="http://localhost/epaypower/css/addInput.css"/>
    <link rel="stylesheet" href="http://localhost/epaypower/css/addSelect.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
    <style>
        .menu a{
            text-decoration: none;
        }
        .menu div{
            padding: 10px;
        }
    </style>
</head>
<body>
<div class="container-fluid text-light pl-5 pt-1 pb-1" style="max-height: 50px; background-color: red">
    <span><i class="fa fa-phone-alt small"></i> 08064511186</span>&emsp;
    <span><i class="fab fa-whatsapp small"></i> 08064511186</span>&emsp;
    <span><a href="" class="text-light">Lost your token?</a></span>
</div>
<div class="container-fluid row bg-white" style="max-height: 100px">
    <div class="col-6 pt-2">
        <img src="http://localhost/epaypower/images/epaylogo.png" alt="EPAYPOWER" class="img-fluid" height="80" width="80"/>
    </div>
    <div class="col-6 pt-4" align="right">
        <a  class="btn shadow rounded bg-light" style="color: red" href="#register" rel="modal:open">Register</a>
        <a  class="btn shadow rounded bg-light" style="color: red" href="#login" rel="modal:open">Login</a>
    </div>
</div>

<!-- Login Modal -->
<div class="login modal animated slideInUp" id="login">
    <p class="text-center h3"><b>LOGIN HERE</b></p>
    <form action="">
        <div class="form-group">
            <input type="email" data-addui='input' class="login_email" placeholder="Enter your email/phone number" >
        </div>
        <div class="form-group">
            <input type="password" data-addui='input' class="login_password" placeholder="Enter password">
        </div>
        <div class="form-group">
            <a href="#forgot_password" rel="modal:open" class="text-uppercase text-muted">forgot password?</a><br/><br/>
            <input type="hidden" name="identity" value="login"/>
            <input type="submit" value="LOGIN" name="login_btn" class="btn login_btn text-light btn-block" style="background-color: red"/>
        </div>
    </form>

</div>

<!-- forgot password Modal -->
<div class="login modal animated slideInUp" id="forgot_password">
    <p class="text-center h3"><b>Recover your password here</b></p>
    <form action="">
        <div class="form-group">
            <input type="email" data-addui='input' class="forgot_email" name="forgot_email" placeholder="Enter your email/phone number" >
        </div>

        <div class="form-group">
            <a href="#login" rel="modal:open" class="text-uppercase text-muted">Go back to login</a><br/><br/>
            <input type="hidden" name="identity" value="forgot-password"/>
            <input type="submit" value="RECOVER" name="recover_password_btn" class="btn recover_password_btn text-light btn-block" style="background-color: red"/>
        </div>
    </form>

</div>


<!-- register Modal -->
<div class="register modal animated slideInUp" id="register">
    <p class="text-center h3"><b>Join the e-pay power community</b></p>
    <form action="">
        <div class="form-group row">
            <div class="col-lg-6">
                <input type="text" name="firstname" placeholder="First name" data-addui="input"/>
            </div>
            <div class="col-lg-6">
                <input type="text" name="lastname" placeholder="Last name" data-addui="input"/>
            </div>
        </div>
        <div class="form-group">
            <input type="tel" name="phone" data-addui="input" placeholder="Enter phone number"/>
        </div>
        <div class="form-group">
            <input type="email" data-addui='input' name="register_email" class="register_email" placeholder="Enter your email" >
        </div>
        <div class="form-group row">
            <div class="col-lg-6">
                <input type="password" name="register_password" data-addui='input' class="register_password" placeholder="Enter password">
            </div>
            <div class="col-lg-6">
                <input type="password" name="confirm_register_password" data-addui='input' class="confirm_register_password" placeholder="Confirm password">
            </div>
        </div>

        <div class="form-group">
            <input type="hidden" name="identity" value="register"/>
            <input type="submit" value="REGISTER" name="register_btn" class="btn register_btn text-light btn-block" style="background-color: red"/>
        </div>
    </form>
</div>

