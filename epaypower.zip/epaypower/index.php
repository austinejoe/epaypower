<?php //php opening tag
//I like to create a single file header which contains all the information needed in the header section. This works for easy modification
//of content in the header. The same thing also happens for footer file.

include_once 'h&f/header.php'; //including header file at the appropriate place
?>
<div class="container-fluid row">
    <div class="col-lg-1 container-fluid menu" style=" background-color: red; right:15px;">
        <nav class="navbar navbar-expand-sm" style="right: 45px">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="fa fa-times text-light"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="nav flex-column" style="width: 100%;">
                    <li class="nav-item">
                        <div class="pt-2 text-center">
                            <a href="" class="text-light h5 nav-link"><i class="fa fa-lightbulb h2"></i><br/>Electricity</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="pt-2 text-center">
                            <a href="" class="text-light h5 nav-link"><i class="fa fa-globe-africa h2"></i><br/>Data</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="pt-2 text-center">
                            <a href="" class="text-light h5 nav-link"><i class="fa fa-mobile-alt h2"></i><br/>Airtime</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <div class="pt-2 text-center">
                            <a href="" class="text-light h5 nav-link"><i class="fa fa-tv h2"></i><br/>TV</a>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
    <div class="col-lg-11 container-fluid pt-3">
    <div class="row container-fluid">
        <div class="col-lg-8" id="render_page" >
            <div class="electricity bg-light shadow rounded p-4" style="max-width: 600px">
                <form class="buy_power_form">
                    <p class="text-light"><b>Buy Electricity</b></p>
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <select name="state" data-addui="select" multiple>
                                <option value="">choose option</option>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <select name="state" data-addui="select">
                                <option value="">choose option</option>
                                <option value="Prepaid">Prepaid</option>
                                <option value="Postpaid">Postpaid</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <input type="number" name="meter_number" data-addui="input" placeholder="meter number">
                        </div>
                        <div class="col-lg-6">
                            <input type="number" name="amount" data-addui="input" placeholder="amount">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-lg-6">
                            <input type="email" name="amount" data-addui="input" placeholder="your email">
                        </div>
                        <div class="col-lg-6">
                            <input type="tel" name="phone" data-addui="input" placeholder="your phone number">
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="hidden" name="identity" value="electricity"/>
                        <input type="submit" class="btn btn-block text-light" style="background-color: red" value="Submit"/>
                    </div>
                </form>
            </div>
        </div>
        <div class="col-lg-4">
            <img src="images/phone.png" alt="" class="img-fluid w-75"/>
        </div>
    </div>
        <div class="pl-3 float-right" style="left: -20px"><a href="#">About Us</a> &emsp; <a href="#">T&C</a> &emsp; 2020 - <?php echo date('Y')?> &copy; epay power &emsp; powered by
            <a href="https://atbebeque.com" class="text-dark">Bebeque Limited</a>
        </div>
    </div>
</div>
<?php
include_once 'h&f/footer.php'; //including footer file at the appropriate place