$(document).ready(function(){
    electricity();
function electricity(){
    $.ajax({
        url:'control/load_page.php',
        type:'POST',
        data:{identity:'electricity'},
        success:function(data){
           // $('#render_page').html(data);
        }
    });
}
});
